# Example Validation Report

| claim_id | issue_type       |
|----------|------------------|
| 102      | Missing Data     |
| 103      | Missing Data     |
| 103      | Invalid Provider |
| 103      | Bad Status       |
| 104      | Bad Status       |
